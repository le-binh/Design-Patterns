import Foundation

enum PizzaType: String {
    case cheese = "cheese"
    case greek = "greek"
    case clam = "clam"
    case veggie = "veggie"
}

class Pizza {
    func prepare() {}
    func bake() {}
    func cut() {}
    func box() {}
}

class CheesePizza: Pizza {}
class GreekPizza: Pizza {}
class ClamPizza: Pizza {}
class VeggiePizza: Pizza {}

class PizzaStore {
    func orderPizza(type: PizzaType) -> Pizza {
        let pizza: Pizza
        switch type {
        case .cheese:
            pizza = CheesePizza()
        case .greek:
            pizza = GreekPizza()
        case .clam:
            pizza = ClamPizza()
        case .veggie:
            pizza = VeggiePizza()
        }
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza
    }
}

//Client code
let store = PizzaStore()
store.orderPizza(type: .cheese)

//What varies is number of pizzas. 
//When we need to add/remove some pizzas
//We need to edit the code logic creating the pizzas