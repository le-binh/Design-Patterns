//: [Previous](@previous)

import Foundation

enum PizzaType: String {
    case cheese = "cheese"
    case greek = "greek"
    case clam = "clam"
    case veggie = "veggie"
}

class Pizza {
    func prepare() {}
    func bake() {}
    func cut() {}
    func box() {}
}

class CheesePizza: Pizza {}
class GreekPizza: Pizza {}
class ClamPizza: Pizza {}
class VeggiePizza: Pizza {}

class SimplePizzaFactory {
    func createPizza(type: PizzaType) -> Pizza {
        let pizza: Pizza
        switch type {
        case .cheese:
            pizza = CheesePizza()
        case .greek:
            pizza = GreekPizza()
        case .clam:
            pizza = ClamPizza()
        case .veggie:
            pizza = VeggiePizza()
        }
        return pizza
    }
}

class PizzaStore {
    let pizzaFactory: SimplePizzaFactory
    init(pizzaFactory: SimplePizzaFactory) {
        self.pizzaFactory = pizzaFactory
    }
    
    func orderPizza(type: PizzaType) -> Pizza {
        let pizza = pizzaFactory.createPizza(type: type)
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza
    }
}

class NewYorkPizzaFactory: SimplePizzaFactory {}
class ChicagoPizzaFactory: SimplePizzaFactory {}

let pizzaFactory: SimplePizzaFactory = NewYorkPizzaFactory()
let pizzaStore = PizzaStore(pizzaFactory: pizzaFactory)
let pizza = pizzaStore.orderPizza(type: .cheese)
pizza

//: [Next](@next)
