//: [Previous](@previous)

import Foundation

enum PizzaType: String {
    case cheese = "cheese"
    case greek = "greek"
    case clam = "clam"
    case veggie = "veggie"
}

protocol Pizza {
    var name: String { get }
    var dough: String { get }
    var sauce: String { get }
    var toppings: [String] { get set }
    func prepare()
    func bake()
    func cut()
    func box()
}

extension Pizza {
    func prepare() {
        print("Preparing \(name)")
        print("Tossing dough...")
        print("Adding sauce...")
        print("Adding toppings: ")
        for topping in toppings {
            print(" \(topping)")
        }
    }
    
    func bake() {
        print("Bake for 25 minutes at 350")
    }
    
    func cut() {
        print("Cutting the pizza into diagonal slices")
    }
    
    func box() {
        print("Place pizza in official PizzaStore box")
    }
}

class CheesePizza: Pizza {
    var name: String {
        return "Cheese Pizza"
    }
    
    var dough: String {
        return ""
    }
    
    var sauce: String {
        return ""
    }
    
    var toppings: [String] = []
}
class GreekPizza: Pizza {
    var name: String {
        return "Greek Pizza"
    }
    
    var dough: String {
        return ""
    }
    
    var sauce: String {
        return ""
    }
    
    var toppings: [String] = []
}
class ClamPizza: Pizza {
    var name: String {
        return "Clam Pizza"
    }
    
    var dough: String {
        return ""
    }
    
    var sauce: String {
        return ""
    }
    
    var toppings: [String] = []
}
class VeggiePizza: Pizza {
    var name: String {
        return "Veggie Pizza"
    }
    
    var dough: String {
        return ""
    }
    
    var sauce: String {
        return ""
    }
    
    var toppings: [String] = []
}

class NewYorkCheesePizza: CheesePizza {
    override var name: String {
        return "NewYork Style Sauce and " + super.name
    }
    
    override init() {
        super.init()
        toppings.append("Grated Reggiano Cheese")
    }
}
class NewYorkGreekPizza: GreekPizza {}
class NewYorkClamPizza: ClamPizza {}
class NewYorkVeggiePizza: VeggiePizza {}

class ChicagoCheesePizza: CheesePizza {
    override var name: String {
        return "Chicago Style Deep Dish and " + super.name
    }
    
    override init() {
        super.init()
        toppings.append("Shredded Mozzarella Cheese")
    }
}
class ChicagoGreekPizza: GreekPizza {}
class ChicagoClamPizza: ClamPizza {}
class ChicagoVeggiePizza: VeggiePizza {}

class SimplePizzaFactory {
    func createPizza(type: PizzaType) -> Pizza {
        let pizza: Pizza
        switch type {
        case .cheese:
            pizza = CheesePizza()
        case .greek:
            pizza = GreekPizza()
        case .clam:
            pizza = ClamPizza()
        case .veggie:
            pizza = VeggiePizza()
        }
        return pizza
    }
}

protocol PizzaStore {
    func createPizza(type: PizzaType) -> Pizza
}

extension PizzaStore {
    func orderPizza(type: PizzaType)-> Pizza {
        let pizza = createPizza(type: type)
        pizza.prepare()
        pizza.bake()
        pizza.cut()
        pizza.box()
        return pizza
    }
}

class NewYorkPizzaStore: PizzaStore {
    func createPizza(type: PizzaType) -> Pizza {
        switch type {
        case .cheese:
            return NewYorkCheesePizza()
        case .greek:
            return NewYorkGreekPizza()
        case .clam:
            return NewYorkClamPizza()
        case .veggie:
            return NewYorkVeggiePizza()
        }
    }
}

class ChicagoPizzaStore: PizzaStore {
    func createPizza(type: PizzaType) -> Pizza {
        switch type {
        case .cheese:
            return ChicagoCheesePizza()
        case .greek:
            return ChicagoGreekPizza()
        case .clam:
            return ChicagoClamPizza()
        case .veggie:
            return ChicagoVeggiePizza()
        }
    }
}

let store = NewYorkPizzaStore()
let pizza = store.orderPizza(type: .cheese)
pizza


//: [Next](@next)
