//: Playground - noun: a place where people can play

import Foundation

protocol Beverage {
    var description: String { get }
    func cost() -> Double
}

protocol CondimentDecorator: Beverage {
    var beverage: Beverage { get }
}

class HouseBlend: Beverage {
    var description: String {
        return "HouseBlend"
    }
    
    func cost() -> Double {
        return 10
    }
}

class DarkRoast: Beverage {
    var description: String {
        return "DarkRoast"
    }
    
    func cost() -> Double {
        return 20
    }
}

extension CondimentDecorator {
    func getDescription() -> String {
        if beverage is CondimentDecorator {
            return beverage.description + " and " + description
        } else {
            return beverage.description + " with " + description
        }
    }
}

class Milk: CondimentDecorator {
    let beverage: Beverage
    private let milkCost: Double = 2
    private let milkDescription = "Milk"
    init(beverage: Beverage) {
        self.beverage = beverage
    }
    
    var description: String {
        return getDescription()
    }
    
    func cost() -> Double {
        return milkCost + beverage.cost()
    }
}

class Mocha: CondimentDecorator {
    let beverage: Beverage
    private let mochaCost: Double = 4
    private let mochaDescription = "Mocha"
    init(beverage: Beverage) {
        self.beverage = beverage
    }
    
    var description: String {
        return getDescription()
    }
    
    func cost() -> Double {
        return mochaCost + beverage.cost()
    }
}

let houseBlendWithMilkAndMocha = Mocha(beverage: Milk(beverage: HouseBlend()))
houseBlendWithMilkAndMocha.cost()



