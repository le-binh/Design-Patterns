//: Playground - noun: a place where people can play

import UIKit

public class Coffee {
    func prepareRecipe() {
        boilWater()
        brewCoffeeGrinds()
        pourInCup()
        addSugarAndMilk()
    }
    
    func boilWater() {
        print("Boilling water")
    }
    
    func brewCoffeeGrinds() {
        print("Dripping Coffee through filter")
    }
    
    func pourInCup() {
        print("Pouring into cup")
    }
    
    func addSugarAndMilk() {
        print("Adding Sugar and Milk")
    }
}

public class Tea {
    func prepareRecipe() {
        boilWater()
        steepTeaBag()
        pourInCup()
        addLemon()
    }
    
    func boilWater() {
        print("Boilling water")
    }
    
    func steepTeaBag() {
        print("Steeping the tea")
    }
    
    func pourInCup() {
        print("Pouring into cup")
    }
    
    func addLemon() {
        print("Adding Lemon")
    }
}
