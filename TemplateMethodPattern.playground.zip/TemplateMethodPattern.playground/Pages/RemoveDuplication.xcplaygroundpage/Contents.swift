//: [Previous](@previous)

import Foundation

protocol CaffeineBeverage {
    func brew()
    func addCondiments()
    func boilWater()
    func pourInCup()
    func isAddingCondiments() -> Bool //Hook
}

extension CaffeineBeverage {
    func boilWater() {
        print("Boilling water")
    }
    
    func pourInCup() {
        print("Pouring into cup")
    }
    
    func prepareRecipe() { //Template method
        boilWater()
        brew()
        pourInCup()
        if isAddingCondiments() {
            addCondiments()
        }
    }
    
    func isAddingCondiments() -> Bool {
        return true
    }
}

class Coffee: CaffeineBeverage {
    func brew() {
        print("Dripping coffee through filter")
    }
    
    func addCondiments() {
        print("Adding sugar and milk")
    }
}

class Tea: CaffeineBeverage {
    func brew() {
        print("Steeping the tea")
    }
    
    func addCondiments() {
        print("Adding lemon")
    }
    
    func isAddingCondiments() -> Bool {
        return false
    }
}


let coffee = Coffee()
coffee.prepareRecipe()
let tea = Tea()
tea.prepareRecipe()


//: [Next](@next)
