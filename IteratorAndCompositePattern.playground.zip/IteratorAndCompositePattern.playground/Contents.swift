//: Playground - noun: a place where people can play

import Foundation

class MenuItem {
    let name: String
    let description: String
    let vegetarian: Bool
    let price: Double
    
    init(name: String, description: String, vegetarian: Bool, price: Double) {
        self.name = name
        self.description = description
        self.vegetarian = vegetarian
        self.price = price
    }
}

class PancakeHouseMenu {
    private var menuItems: NSMutableArray
    
    init() {
        menuItems = NSMutableArray()
    }
    
    func addItem(name: String, description: String, vegetarian: Bool, price: Double) {
        let item = MenuItem(name: name, description: description, vegetarian: vegetarian, price: price)
        menuItems.add(item)
    }
    
    func getMenuItems() -> NSArray {
        return menuItems
    }
}

class DinerMenu {
    static let maxItems: Int = 6
    var numberOfItems: Int {
        return menuItems.count
    }
    private var menuItems: [MenuItem]
    
    init() {
        menuItems = []
    }
    
    func addItem(name: String, description: String, vegetarian: Bool, price: Double) {
        if numberOfItems >= DinerMenu.maxItems {
            print("Menu is full! Can't add item to menu")
        } else {
            let item = MenuItem(name: name, description: description, vegetarian: vegetarian, price: price)
            menuItems.append(item)
        }
    }
    
    func getMenuItems() -> [MenuItem] {
        return menuItems
    }
}

let pancakeHouseMenu = PancakeHouseMenu()
let breakfaseItems = pancakeHouseMenu.getMenuItems()

let dinerMenu = DinerMenu()
let lunchItems = dinerMenu.getMenuItems()

