//: Playground - noun: a place where people can play

import Foundation

protocol WeaponBehavior {
    func useWeapon()
}

class Character {
    var weapon: WeaponBehavior
    init(weapon: WeaponBehavior) {
        self.weapon = weapon
    }
    
    func fight() {
        weapon.useWeapon()
    }
}

class King: Character {}
class Queen: Character {}
class Knight: Character {}
class Troll: Character {}

class SwordBehavior: WeaponBehavior {
    func useWeapon() {
        print("swinging a sword")
    }
}

let king = King(weapon: SwordBehavior())
king.fight()