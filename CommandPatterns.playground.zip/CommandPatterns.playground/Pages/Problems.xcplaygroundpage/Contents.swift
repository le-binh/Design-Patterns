//: Playground - noun: a place where people can play

import Foundation

protocol ApplianceControl {
    func on()
    func off()
}

class Light: ApplianceControl {
    func on() { print("Light is turned on") }
    func off() { print("Light is turned off") }
}

protocol RemoteControlSlot {
    func on()
    func off()
}

class RemoteControl {
    private var slots: [RemoteControlSlot] = []
    func addSlot(slot: RemoteControlSlot, at index: Int) {
        slots.insert(slot, at: index)
    }
    
    func addSlot(slot: RemoteControlSlot) {
        addSlot(slot: slot, at: slots.count)
    }
    
    func pressedOn(atSlotIndex index: Int) {
        let slot = slots[index]
        slot.on()
    }
    
    func pressedOff(atSlotIndex index: Int) {
        let slot = slots[index]
        slot.off()
    }
    
    func pressedUndo(atSlotIndex index: Int) {
        //MARK:- TODO
    }
}

class LightControl: RemoteControlSlot {
    private let light: Light
    
    init(light: Light) {
        self.light = light
    }
    
    func on() {
        light.on()
    }
    
    func off() {
        light.off()
    }
}

//MARK:- Client Code

let remoteControl = RemoteControl()
let lightControl = LightControl(light: Light())
remoteControl.addSlot(slot: lightControl)
remoteControl.pressedOn(atSlotIndex: 0)
remoteControl.pressedOff(atSlotIndex: 0)