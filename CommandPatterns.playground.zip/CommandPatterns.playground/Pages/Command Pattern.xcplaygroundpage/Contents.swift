//: [Previous](@previous)

import Foundation

protocol Command {
    func execute()
    func undo()
}

protocol ApplianceControl {
    func on()
    func off()
}

class Light: ApplianceControl {
    func on() { print("Light is turned on") }
    func off() { print("Light is turned off") }
}

class CeilingFan: ApplianceControl {
    enum FanSpeed: Int {
        case off, low, medium, high
    }
    
    var speed: FanSpeed = .off
    func change(speed: FanSpeed) {
        self.speed = speed
    }
    
    func on() {
        speed = .low
    }
    
    func off() {
        speed = .off
    }
}

class Stereo: ApplianceControl {
    func on() { print("Stereo is turned on") }
    func off() { print("Stereo is turned off") }
    func setCD() { print("CD is set") }
    func set(volumn: Int) { print("Vomume is set at: \(volumn)") }
}

class LightOnCommand: Command {
    private let light: Light
    
    init(light: Light) {
        self.light = light
    }
    
    func execute() {
        light.on()
    }
    
    func undo() {
        light.off()
    }
}

class LightOffCommand: Command {
    private let light: Light
    
    init(light: Light) {
        self.light = light
    }
    
    func execute() {
        light.off()
    }
    
    func undo() {
        light.on()
    }
}

class StereoOnCommand: Command {
    private let stereo: Stereo
    
    init(stereo: Stereo) {
        self.stereo = stereo
    }
    
    func execute() {
        stereo.on()
        stereo.setCD()
        stereo.set(volumn: 11)
    }
    
    func undo() {
        stereo.off()
    }
}

class StereoOffCommand: Command {
    private let stereo: Stereo
    
    init(stereo: Stereo) {
        self.stereo = stereo
    }
    
    func execute() {
        stereo.off()
    }
    
    func undo() {
        stereo.on()
        stereo.setCD()
        stereo.set(volumn: 11)
    }
}

class CeilingFanCommand: Command {
    let ceilingFan: CeilingFan
    var recentSpeed: CeilingFan.FanSpeed
    init(ceilingFan: CeilingFan) {
        self.ceilingFan = ceilingFan
        self.recentSpeed = ceilingFan.speed
    }
    
    func execute() {
        recentSpeed = ceilingFan.speed
    }
    
    func undo() {
        ceilingFan.change(speed: recentSpeed)
    }
}

class CeilingFanHighCommand: CeilingFanCommand {
    override func execute() {
        super.execute()
        ceilingFan.change(speed: .high)
    }
}

class CeilingFanMediumCommand: CeilingFanCommand {
    override func execute() {
        super.execute()
        ceilingFan.change(speed: .medium)
    }
}

class CeilingFanLowCommand: CeilingFanCommand {
    override func execute() {
        super.execute()
        ceilingFan.change(speed: .low)
    }
}

class CeilingFanOffCommand: CeilingFanCommand {
    override func execute() {
        super.execute()
        ceilingFan.change(speed: .off)
    }
}

class RemoteControl {
    private var onCommands: [Command?]
    private var offCommands: [Command?]
    private var recentCommad: Command?
    init() {
        onCommands = Array<Command?>(repeating: nil, count: 7)
        offCommands = Array<Command?>(repeating: nil, count: 7)
    }
    
    func setCommands(oncommand: Command, offCommand: Command, atSlot index: Int) {
        onCommands[index] = oncommand
        offCommands[index] = offCommand
    }
    
    func pressOnButton(atSlot index: Int) {
        let command = onCommands[index]
        command?.execute()
        recentCommad = command
    }
    
    func pressOffButton(atSlot index: Int) {
        let command = offCommands[index]
        command?.execute()
        recentCommad = command
    }
    
    func pressUndoButton() {
        recentCommad?.undo()
    }
}

//MARK:- Client code

let remoteControl = RemoteControl()
let light = Light()
let lightOnCommand = LightOnCommand(light: light)
let lightOffCommand = LightOffCommand(light: light)
let stereo = Stereo()
let stereoOnCommand = StereoOnCommand(stereo: stereo)
let stereoOffCommand = StereoOffCommand(stereo: stereo)

remoteControl.setCommands(oncommand: lightOnCommand, offCommand: lightOffCommand, atSlot: 0)
remoteControl.setCommands(oncommand: stereoOnCommand, offCommand: stereoOffCommand, atSlot: 1)
remoteControl.pressOnButton(atSlot: 0)
remoteControl.pressOnButton(atSlot: 1)
remoteControl.pressOffButton(atSlot: 1)
remoteControl.pressUndoButton()

//: [Next](@next)
