//: [Previous](@previous)

import Foundation

protocol Context {
    var state: State { get set }
}

protocol State {
    func insertQuarter(in context: Context)
    func ejectQuarter(in context: Context)
    func turnCrank(in context: Context) -> Bool
}

class NoQuarterState: State {
    func insertQuarter(in context: Context) {
        var context = context
        print("You inserted a quarter")
        context.state = HasQuarterState()
    }
    
    func ejectQuarter(in context: Context) {
        print("You have not inserted a quarter")
    }
    
    func turnCrank(in context: Context) -> Bool {
        print("You turned, but there's no quarter")
        return false
    }
}

class HasQuarterState: State {
    func insertQuarter(in context: Context) {
        print("You can't inserted another quarter")
    }
    
    func ejectQuarter(in context: Context) {
        print("Quarter returned")
    }
    
    func turnCrank(in context: Context) -> Bool {
        var context = context
        print("You turned")
        context.state = SoldState()
        return true
    }
}

class SoldOutState: State {
    func insertQuarter(in context: Context) {
        print("Can't insert a quarter, the machine is sold out")
    }
    
    func ejectQuarter(in context: Context) {
        print("Can't eject, you haven't inserted a quarter yet")
    }
    
    func turnCrank(in context: Context) -> Bool {
        print("You turned, but there's no gumballs")
        return false
    }
}

class SoldState: State {
    func insertQuarter(in context: Context) {
        print("Please wait, we're already giving you a gumball")
    }
    
    func ejectQuarter(in context: Context) {
        print("Sorry, you already turned the crank")
    }
    
    func turnCrank(in context: Context) -> Bool {
        print("Turning twice doesn't get you another gumball")
        return false
    }
}

class GumballMachine: Context {
    var state: State
    
    var numberOfGumballs: Int = 0
    var isSoldOut: Bool {
        return numberOfGumballs <= 0
    }
    
    init(numberOfBumballs: Int) {
        self.numberOfGumballs = numberOfBumballs
        if numberOfBumballs > 0 {
            state = NoQuarterState()
        } else {
            state = SoldOutState()
        }
    }
    
    func insertQuarter() {
        state.insertQuarter(in: self)
    }
    
    func ejectQuarter() {
        state.ejectQuarter(in: self)
    }
    
    func turnCrank() {
        if state.turnCrank(in: self) {
            dispense()
        }
    }
    
    func refill(count: Int) {
        print("Filled")
        self.numberOfGumballs = count
        state = NoQuarterState()
    }
    
    private func dispense() {
        releaseBall()
        if isSoldOut {
            print("Oops, out of gumballs")
            state = SoldOutState()
        } else {
            state = NoQuarterState()
        }
    }
    
    private func releaseBall() {
        if !isSoldOut {
            print("A gumball comes rolling out the slot...")
            numberOfGumballs = numberOfGumballs - 1
        }
    }
}

let gumballMachine = GumballMachine(numberOfBumballs: 5)
gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.insertQuarter()
gumballMachine.ejectQuarter()
gumballMachine.turnCrank()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.ejectQuarter()

gumballMachine.insertQuarter()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.refill(count: 5)
gumballMachine.insertQuarter()
gumballMachine.turnCrank()

//: [Next](@next)
