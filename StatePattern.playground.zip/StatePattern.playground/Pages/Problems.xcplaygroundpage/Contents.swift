//: [Previous](@previous)

import Foundation

enum State: Int {
    //NEW:- add 1 more case: winner
    case soldOut, noQuarter, hasQuarter, sold, winner
}

class GumballMachine {
    var state: State = .soldOut
    var count: Int = 0
    
    init(count: Int) {
        self.count = count
        if count > 0 {
            state = .noQuarter
        }
    }
    
    func insertQuarter() {
        switch state {
        case .hasQuarter:
            print("You can't inserted another quarter")
        case .noQuarter:
            state = .hasQuarter
            print("You inserted a quarter")
        case .soldOut:
            print("Can't insert a quarter, the machine is sold out")
        case .sold:
            print("Please wait, we're already giving you a gumball")
        case .winner:
            //TODO:- do something
            print("")
        }
    }
    
    func ejectQuarter() {
        switch state {
        case .hasQuarter:
            print("Quarter ejected")
            state = .noQuarter
        case .noQuarter:
            print("You haven't inserted a quarter")
        case .soldOut:
            print("Can't eject, you haven't inserted a quarter yet")
        case .sold:
            print("Sorry, You already turned the crank")
        case .winner:
            //TODO:- do something
            print("")
        }
    }
    
    func turnCrank() {
        switch state {
        case .hasQuarter:
            print("You turned")
            //TODO:- Check for winner
            state = .sold
            dispense()
        case .noQuarter:
            print("You turned, but there's no quarter")
        case .soldOut:
            print("You turned, but there's no gumballs")
        case .sold:
            print("Turning twice doesn't get you another gumball")
        case .winner:
            //TODO:- do something
            print("")
        }
    }
    
    func dispense() {
        switch state {
        case .hasQuarter:
            print("No gumball dispensed")
            state = .sold
        case .noQuarter:
            print("You need to pay first")
        case .soldOut:
            print("No gumball dispensed")
        case .sold:
            print("A gumball comes rolling out the slot")
            count = count - 1
            if count == 0 {
                print("Oops, out of gumballs")
                state = .soldOut
            } else {
                state = .noQuarter
            }
        case .winner:
            //TODO:- do something
            print("")
        }
    }
}

let gumballMachine = GumballMachine(count: 5)
gumballMachine.insertQuarter()
gumballMachine.turnCrank()

//: [Next](@next)
